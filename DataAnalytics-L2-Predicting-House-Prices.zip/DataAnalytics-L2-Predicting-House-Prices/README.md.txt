# House Price Prediction Using Linear Regression

## Project Overview
This project focuses on predicting house prices using Machine Learning. Linear Regression is used to understand the relationship between house features and their prices.

## Objective
The main objective is to build a machine learning model that predicts house prices based on different property features.

## Dataset Information
- Total Records: 2,000
- Total Columns: 10
- Target Variable: Price
- Numerical and categorical features are included.

## Tools & Technologies
- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn
- Jupyter Notebook

## Steps Performed
1. Loaded and explored the dataset.
2. Checked missing values and duplicate records.
3. Performed descriptive statistical analysis.
4. Visualized house price distribution.
5. Selected relevant features.
6. Applied One-Hot Encoding.
7. Created a correlation heatmap.
8. Split data into training and testing sets (80:20).
9. Trained a Linear Regression model.
10. Evaluated model performance using MSE, RMSE, and R² Score.
11. Created Actual vs Predicted and Residual plots.
12. Analyzed model coefficients.
13. Applied Ridge Regression.
14. Compared Linear Regression and Ridge Regression.

## Model Evaluation
Model performance was evaluated using:
- Mean Squared Error (MSE)
- Root Mean Squared Error (RMSE)
- R² Score

## Conclusion
This project demonstrates the application of Linear Regression and Ridge Regression for house price prediction. Data preprocessing, visualization, model training, and evaluation were performed to understand the machine learning workflow.