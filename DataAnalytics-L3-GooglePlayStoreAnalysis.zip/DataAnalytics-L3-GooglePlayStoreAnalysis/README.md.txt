# 📱 Google Play Store Analysis

## 📌 Project Overview
The Google Play Store Analysis project focuses on exploring the Android app ecosystem using Python. The objective is to analyze app categories, ratings, installations, pricing trends, and user reviews to discover meaningful business insights.

## 🎯 Project Objectives
- Analyze app distribution across different categories.
- Understand app ratings and user preferences.
- Explore the relationship between app size and installations.
- Compare Free and Paid applications.
- Estimate revenue across app categories.
- Perform sentiment analysis on user reviews.
- Identify business opportunities for app developers.

## 🛠️ Tech Stack
- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- TextBlob
- Plotly
- Jupyter Notebook

## 📂 Datasets
1. Google Play Store Apps Dataset
2. Google Play Store User Reviews Dataset

## 🔍 Project Workflow

### 1. Data Cleaning
- Handled missing values.
- Removed duplicate records.
- Converted incorrect data types.
- Cleaned Installs, Price, Size, and Reviews columns.

### 2. Exploratory Data Analysis (EDA)
- App distribution by category.
- Top 10 app categories.
- Ratings distribution.
- Average ratings by category.
- App Size vs Installs analysis.
- Correlation analysis.

### 3. Pricing Analysis
- Free vs Paid app comparison.
- Paid app price distribution.
- Average price by category.
- Estimated revenue by category.

### 4. Sentiment Analysis
- Cleaned user reviews.
- Used TextBlob for sentiment polarity.
- Classified reviews into Positive, Negative, and Neutral.
- Analyzed sentiment across app categories.

### 5. Interactive Visualization
Created interactive visualizations using Plotly to explore category-wise user sentiment.

## 📊 Key Business Insights
- Identify highly competitive app categories.
- Understand user satisfaction through ratings and reviews.
- Explore pricing and estimated revenue opportunities.

## 💡 Business Recommendations
- Research market competition before launching a new application.
- Focus on app quality and user experience.
- Use customer feedback to improve application performance.
- Choose competitive pricing strategies.

## 📌 Conclusion
This project helped me develop practical skills in data cleaning, exploratory data analysis, data visualization, and sentiment analysis. It also provided insights into user preferences and market opportunities in the Google Play Store ecosystem.

## 👨‍💻 Author
Mohammed Suhail

B.Tech – Computer Science & Engineering (2026)

Aspiring Data Analyst

**Skills:** Python | SQL | Pandas | NumPy | Matplotlib | Seaborn | Power BI | Data Analysis